package View;

import java.util.Scanner;

public class All {
    
    public static void main(String[] args) {
        
        Scanner sc=new Scanner(System.in);
        BankAccount b=new BankAccount("Ritik","01");
        b.showMenu();
        
    }
}
class BankAccount{
    
    int balance;
    int previousTransaction;
    String customerName;
    String customerId;

    BankAccount(String cname,String cid) {
        customerName=cname;
        customerId=cid;
    }
            
    void deposit(int amount){
        
        if(amount!=0){
            balance=balance+amount;
            previousTransaction=amount;
        }
    }
    
    void withdraw(int amount){
        
        if(amount!=0){
            balance=balance-amount;
            previousTransaction=-amount;
        }
    }
    
    void getpreviousTransaction(){
        
        if(previousTransaction>0){
            System.out.println("Deposited:"+previousTransaction);
        }
        else if(previousTransaction<0){
            System.out.println("Withdrawn:"+Math.abs(previousTransaction));
    }
        else{
            System.out.println("No transaction is occured!");
        }
    }
    
    void showMenu(){
        char option='\0';
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Welcome "+customerName);
        System.out.println("Your ID is:"+customerId);
        System.out.println();
        System.out.println("A. Check Balance");
        System.out.println("B. Deposit");
        System.out.println("C. Withdraw");
        System.out.println("D. Previous Transaction");
        System.out.println("E. Exit");
        
        do{
            System.out.println("Enter the option");
            option=sc.next().charAt(0);
           // Character.toUpperCase(option);
            
            switch(option){
                case 'A':
                    System.out.println("Balance is:"+balance);
                    System.out.println();
                    break;
                    
                case 'B':
                    System.out.println("enter the amount to deposit");
                    int amount=sc.nextInt();
                    deposit(amount);
                    System.out.println();
                    break;
                    
                case 'C':
                    System.out.println("enter the amount to withdraw");
                    int amount2=sc.nextInt();
                    withdraw(amount2);
                    System.out.println();
                    break;
                    
                case 'D':
                    getpreviousTransaction();
                    System.out.println();
                    break;
                    
                case 'E':
                    break;
                    
                default:
                    System.out.println("Invalid Option!Please try again");
                    break;
            }
        }while(option!='E');
    }
}
