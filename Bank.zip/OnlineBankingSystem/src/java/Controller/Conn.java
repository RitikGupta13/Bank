package Controller;

import Model.Bean;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Conn {

    public static Connection getConn() {

        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public static int save(Bean obj) {

        int i = 0;

        try {

            Connection con = Conn.getConn();
            PreparedStatement ps = con.prepareStatement("insert into customer (name,anumber,city,state,mnumber,accounttype,password,cpassword)values (?,?,?,?,?,?,?,?)");

            ps.setString(1, obj.getName());
            ps.setInt(2, obj.getAnumber());
            ps.setString(3, obj.getCity());
            ps.setString(4, obj.getState());
            ps.setInt(5, obj.getMnumber());
            ps.setString(6, obj.getAccounttype());
            ps.setString(7, obj.getPassword());
            ps.setString(8, obj.getCpassword());

            i = ps.executeUpdate();
            System.out.println("Your data is submitted" + i);
        } catch (Exception e) {

            System.out.println(e);
        }
        return i;
    }

    public static List<Bean> getAllEmployees() {

        List<Bean> list = new ArrayList<Bean>();

        try {

            Connection con = Conn.getConn();
            PreparedStatement ps = con.prepareStatement("select * from customer");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Bean e = new Bean();
                e.setId(rs.getInt(1));
                e.setName(rs.getString(2));
                e.setAnumber(rs.getInt(3));
                e.setCity(rs.getString(4));
                e.setState(rs.getString(5));
                e.setMnumber(rs.getInt(6));
                e.setAccounttype(rs.getString(7));
                e.setPassword(rs.getString(8));
                e.setCpassword(rs.getString(9));

                list.add(e);
            }
            con.close();
        } catch (Exception e) {

            e.printStackTrace();
        }

        return list;
    }

    public static Bean getId(int id) {

        Bean e = new Bean();
        try {
            Connection con = Conn.getConn();
            PreparedStatement ps = con.prepareStatement("select * from customer where id=?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                e.setId(rs.getInt(1));
                e.setName(rs.getString(2));
                e.setAnumber(rs.getInt(3));
                e.setCity(rs.getString(4));
                e.setState(rs.getString(5));
                e.setMnumber(rs.getInt(6));
                e.setAccounttype(rs.getString(7));
                e.setPassword(rs.getString(8));
                e.setCpassword(rs.getString(9));
            }
        } catch (Exception e1) {
            System.out.println(e1);
        }
        return e;
    }

    public static int update(Bean e) {
        int status = 0;
        try {
            Connection con = Conn.getConn();
            PreparedStatement ps = con.prepareStatement("update customer set name=?,anumber=?,city=?,state=?,mnumber=?,accounttype=?,password=?,cpassword=? where id=?");

            ps.setString(1, e.getName());
            ps.setInt(2, e.getAnumber());
            ps.setString(3, e.getCity());
            ps.setString(4, e.getState());
            ps.setInt(5, e.getMnumber());
            ps.setString(6, e.getAccounttype());
            ps.setString(7, e.getPassword());
            ps.setString(8, e.getCpassword());
            ps.setInt(9, e.getId());

            status = ps.executeUpdate();
            con.close();
        } catch (Exception e2) {
            System.out.println(e2);
        }
        return status;
    }

    public static int delete(int id) {

        int status = 0;
        try {
            Connection con = Conn.getConn();
            PreparedStatement ps = con.prepareStatement("delete from customer where id=?");

            ps.setInt(1, id);
            status = ps.executeUpdate();
            con.close();
        } catch (Exception e3) {
            System.out.println(e3);
        }
        return status;
    }

    public static Connection getCon() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "");
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

    public static int deposit(Bean obj1){
        int i=0;
        try{
            Connection con=Conn.getConn();
            PreparedStatement ps=con.prepareStatement("insert into deposit (anumber,amount,balance) values(?,?,?)");
            
            ps.setInt(1, obj1.getAnumber());
            ps.setInt(2, obj1.getAmount());
            ps.setInt(3, obj1.getBalance());
            
           i= ps.executeUpdate();
            System.out.println("Your amount is deposited"+i);
        }
        catch(Exception e){
            System.out.println(e);
        }
        return i;
    }
}
